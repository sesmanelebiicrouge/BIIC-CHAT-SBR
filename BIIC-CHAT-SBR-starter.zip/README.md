# BIIC CHAT — SBR

Application de messagerie multiplateforme :
- Android
- iOS / iPadOS
- Web

## Vision

BIIC CHAT — SBR permettra aux utilisateurs de :
- créer un compte et se connecter ;
- discuter en privé ;
- créer et utiliser des groupes ;
- envoyer des messages en temps réel ;
- partager progressivement des fichiers et images ;
- recevoir des notifications.

## Stack de départ

- Flutter / Dart pour l'application multiplateforme
- Backend et base de données à ajouter après validation du socle
- GitHub Actions pour l'analyse et les builds cloud

## Développement sans ordinateur

Le dépôt peut être préparé et modifié depuis un téléphone via GitHub.
Le workflow `.github/workflows/flutter.yml` prépare les plateformes Flutter dans l'environnement cloud puis vérifie et construit l'application.

## Identifiant technique

Nom du projet Flutter : `biic_chat_sbr`

## Étapes

1. Importer ce contenu dans le dépôt GitHub `BIIC-CHAT-SBR`.
2. Attendre l'exécution de GitHub Actions.
3. Vérifier le build Android et le build Web.
4. Ajouter ensuite l'authentification et le backend.
