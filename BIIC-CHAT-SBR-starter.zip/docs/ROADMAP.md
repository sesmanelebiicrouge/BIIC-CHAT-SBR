# Feuille de route BIIC CHAT — SBR

## Phase 0 — Socle
- [x] Dépôt GitHub
- [x] Projet Flutter
- [x] Interface de démarrage
- [x] Analyse et tests automatisés
- [x] Build Android cloud
- [x] Build Web cloud

## Phase 1 — Identité
- [ ] Inscription
- [ ] Connexion
- [ ] Déconnexion
- [ ] Profil utilisateur
- [ ] Gestion de session

## Phase 2 — Messagerie
- [ ] Liste des conversations
- [ ] Conversation privée
- [ ] Envoi de messages
- [ ] Réception en temps réel
- [ ] Statut lu/non lu

## Phase 3 — Groupes
- [ ] Création d'un groupe
- [ ] Membres
- [ ] Administrateurs
- [ ] Messages de groupe

## Phase 4 — Médias et notifications
- [ ] Images
- [ ] Fichiers
- [ ] Notifications push
- [ ] Présence en ligne

## Phase 5 — Production
- [ ] Sécurité
- [ ] Tests
- [ ] Sauvegardes
- [ ] Déploiement Web
- [ ] Publication Android
- [ ] Publication iOS
