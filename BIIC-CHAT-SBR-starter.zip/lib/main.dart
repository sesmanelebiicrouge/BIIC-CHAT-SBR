import 'package:flutter/material.dart';

void main() {
  runApp(const BiicChatApp());
}

class BiicChatApp extends StatelessWidget {
  const BiicChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BIIC CHAT — SBR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: const Color(0xFF1F6FEB),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BIIC CHAT — SBR'),
        actions: [
          IconButton(
            tooltip: 'Profil',
            onPressed: () {},
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bienvenue sur BIIC CHAT',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Le socle de l’application est prêt. '
                    'La prochaine étape sera l’authentification puis la messagerie.',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const _FeatureTile(
            icon: Icons.chat_bubble_outline,
            title: 'Conversations',
            subtitle: 'Les discussions privées seront disponibles ici.',
          ),
          const _FeatureTile(
            icon: Icons.groups_outlined,
            title: 'Groupes',
            subtitle: 'Création et discussions de groupe.',
          ),
          const _FeatureTile(
            icon: Icons.notifications_none,
            title: 'Notifications',
            subtitle: 'À ajouter avec le backend.',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {},
        icon: const Icon(Icons.chat_outlined),
        label: const Text('Nouveau'),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}
